--Comp3311 Assignment1

--1.List all persons who are both clients and staff members. Order the result by pid in ascending order.

create or replace view Q1(pid, firstname, lastname) as
select p.pid, p.firstname, p.lastname
from person p, client c, staff s
where p.pid = c.pid and p.pid = s.pid
group by p.pid
order by p.pid asc
;

--2.For each car brand, list the car insured by the most expensive policy (the premium, i.e., the sum of its coverages' rates). Order the result by brand, and then by car id, pno if there are ties, all in ascending order. 

create or replace view Allcars(brand, car_id, pno, premium) as
select i.brand, i.id, p.pno, r.rate
from insured_item i, policy p, rating_record r, coverage c
where i.id = p.id and p.pno = c.pno and c.coid = r.coid
;

create or replace view Expensive(brand, price) as 
select brand, max(premium)
from Allcars
group by brand
;

create or replace view Q2(brand, car_id, pno, premium) as
select a.brand, car_id, pno, max(premium)
from Allcars a, Expensive e
where a.brand = e.brand and a.premium = e.price
group by a.brand, car_id, pno
order by a.brand asc, car_id asc, pno asc
;

--3.List all the staff members who did not sell any policies in the last 365 calendar days (from today). Note that policy.sid records the staff who sold this policy, underwritten_by.wdate records the date a policy is sold (we ignore the status here). Order the result by pid in ascending order. 

create or replace view HavePolicy(pid, firstname, lastname) as
select s.pid, p.firstname, p.lastname
from staff s, person p, underwritten_by u, underwriting_record uwr, policy po
where po.pno = uwr.pno and uwr.urid = u.urid and s.pid = p.pid and s.sid = po.sid and u.wdate >= CURRENT_DATE - INTERVAL '1 YEAR' and u.wdate <= CURRENT_DATE
group by s.pid, p.firstname, p.lastname
;

create or replace view Q3(pid, firstname, lastname) as
select s.pid, p.firstname, p.lastname
from staff s, person p, underwritten_by u, policy po, HavePolicy h
where s.pid not in (select pid from HavePolicy) and s.pid = p.pid
group by s.pid, p.firstname, p.lastname
order by s.pid asc
;

--4.For each suburb in NSW, compute the number of policies that have been sold to the policy holders living in the suburb (regardless of the policy status). Order the result by Number of Policies (npolicies), then by suburb, in ascending order. Exclude suburbs with no sold policies. Furthermore, suburb names are output in all uppercase. 

create or replace view NSW_suburbs(suburb, policy) as
select p.suburb, po.pno
from person p, client c, policy po, insured_by i
where p.state = 'NSW' and p.pid = c.pid and i.cid = c.cid and po.pno = i.pno
;

create or replace view Q4(suburb, npolicies) as
select UPPER(N.suburb), count(*)
from NSW_suburbs N
group by N.suburb
order by count(*) asc, N.suburb asc
;

--5.Find the policies which are rated, underwritten, and sold by the same staff member. Order the result by pno in ascending order. 

create or replace view Q5(pno, pname, pid, firstname, lastname) as
select po.pno, po.pname, p.pid, p.firstname, p.lastname
from person p, policy po, staff s, rated_by r, underwritten_by u, underwriting_record ur, coverage c, rating_record rr
where p.pid = s.pid and s.sid = r.sid and s.sid = u.sid and po.sid = u.sid and u.urid = ur.urid and ur.pno = po.pno and rr.rid = r.rid and rr.coid = c.coid and c.pno = po.pno
order by po.pno asc
;
--6.List the staff members (their firstname, a space and then the lastname as one column called name) who only sell policies to cover one brand of cars. Order the result by pid in ascending order. 

create or replace view per_brands(pid, name, pno, brand) as
select p.pid, p.lastname, po.pno, i.brand
from person p, staff s, policy po, insured_item i
where p.pid = s.pid and s.sid = po.sid and po.id = i.id
group by p.pid, p.lastname, po.pno, i.brand
;

create or replace view howmany_brand(pid, name, brands) as
select p.pid, p.lastname, count(*)
from person p, per_brands pe
where p.lastname = pe.name and p.pid = pe.pid
group by p.pid, p.lastname, pe.brand
;

create or replace view how_brand(pid, name, brands) as
select p.pid, p.lastname, count(*)
from person p, howmany_brand h
where p.lastname = h.name and p.pid = h.pid
group by p.pid, p.lastname
;

create or replace view Q6(pid, name, brand) as
select p.pid, CONCAT(p.firstname, ' ', p.lastname), i.brand
from person p, staff s, policy po, insured_item i, how_brand h
where p.pid = s.pid and s.sid = po.sid and po.id = i.id and h.brands <= 1 and h.pid = p.pid
;

--7.List clients (their firstname, a space and then the lastname as one column called name) who hold policies to cover all brands of cars recorded in the database. Order the result by pid in ascending order. 

create or replace view clients_po_brand(pid, name, brand) as
select p.pid, CONCAT(p.firstname, ' ', p.lastname), i.brand
from person p, client c, policy po, insured_item i, insured_by ib
where p.pid = c.pid and c.cid = ib.cid and ib.pno = po.pno and po.id = i.id
group by p.pid, i.brand
;

create or replace view howmany_client(pid, name, brands) as
select p.pid, CONCAT(p.firstname, ' ', p.lastname), count(*)
from person p, clients_po_brand cl
where p.pid = cl.pid
group by p.pid
;

create or replace view howmany_brands(brand) as
select distinct ii.brand
from insured_item ii
group by ii.brand
;

create or replace view Q7(pid, name) as
select p.pid, CONCAT(p.firstname, ' ', p.lastname)
from person p, howmany_client hc
where  p.pid = hc.pid and hc.brands >= (select count(*) from howmany_brands)
;

--8.For each policy X, compute the number of other policies (excluding X) whose coverage is contained by the coverage of X. For example, if a policy X has 3 coverages (identified by cname), say {C1, C2, C3}, and another policy Y has 2 coverages, {C1, C3}, we say Y's coverage is contained by X's. In case if X's and Y's coverages are identical, their coverages are contained by each other. Order the result by pno in ascending order. Exclude policies that contain no other policies in your output (i.e., exclude those with npolicies being 0). 

create or replace view policy_coverage(coid, pno, cname) as
select c.coid, po.pno, c.cname
from policy po, coverage c
where po.pno = c.pno
order by po.pno
;

create or replace view counts(pno, counta) as
select pno,count(*)
from policy_coverage
group by pno
order by pno
;

create or replace view policy_copy(coid, pno, cname) as
select *
from policy_coverage
order by pno
;

create or replace view conP(pno, cname) AS
select pno, array_to_string(array_agg(cname), ',')
from policy_coverage
group by pno
order by pno
;

create or replace view result(pno, npolicies) as
select *
from conP
order by pno
;

create table result_table as select * from result;

create or replace function 
      CountP()
      returns TABLE (
      countnum INT
)
as $$
declare
    i record;
    j record;
    lasti integer := 0;    
    lastone integer := 0; 
    belong integer := 0;
    count_p integer := 0;
    lastpno integer := 100;
    switch integer := 0;
begin
--raise notice '%',count_p;
    select count(*) into switch from policy_coverage where pno = (select max(pno) from policy);
    for i in select pno, cname from conP loop
        lasti := lasti + 1;
        for j in select pno, cname from policy_coverage loop
            lastone := lastone + 1;
            if i.pno <> j.pno then
                if lastpno <> j.pno and lastpno <> 100 and belong = 0 then 
                    count_p := count_p + 1;
                end if;
                
                if lastpno <> j.pno and lastpno <> 100 and belong = 1 then
                    belong := 0;
                end if;
                
                if position(j.cname in i.cname) > 0 then 
                    --switch := switch + 1;
                else
                    --switch := switch + 1;
                    belong := 1;
                end if;
                
                if lastone = (select count(*) from policy_coverage) then
                    if belong = 0 then
                        count_p := count_p + 1;
                    else
                        belong := 0;
                    end if;
                end if;
                
                if lasti = (select count(*) from conP) and lastone = (select count(*) from policy_coverage) - switch then
                    if belong = 0 then
                        count_p := count_p + 1;
                    else
                        belong := 0;
                    end if;
                end if;
                
                lastpno := j.pno;
            end if;
            --raise notice '%',count_p;
         end loop;
         countnum := count_p;
         --switch := lastone;
         lastone := 0;
         lastpno := 100;
         --belong := 0;
         
         update result_table
         set npolicies = count_p
         where pno = i.pno;
         
         --switch := switch + count_p;
         count_p := 0;
         return next;
     end loop;
     --return switch;
end;
$$ language plpgsql;               

select CountP();

create or replace view Q8(pno, npolicies) as
select *
from result_table
;

--9.Create a stored function that increases/decreases the rate by Adj% for all active (as of today) and enforced (with status E) policies. Other policies shall not be affected. Adj is an integer between -99 and 99. For example, if the original rate is 200 and Adj is -20, the new rate will be 160. If the original rate is 300 and Adj is 10, the new rate will be 330. The function returns the number of policies that have been adjusted.

create or replace view changed(pno, rid) as 
select p.pno, rr.rid
from policy p, coverage c, rating_record rr
where p.pno = c.pno and c.coid = rr.coid and p.status ='E' and p.effectivedate <= CURRENT_DATE and CURRENT_DATE <= p.expirydate
group by p.pno, rr.rid;

create or replace function ratechange(Adj integer) returns integer
as $$
declare 
    res integer;
    countb integer;
    i record;
    j record;
begin
    select count(*) into countb from changed;
    for i in select effectivedate, expirydate, status, pno from policy loop
        if (i.effectivedate <= CURRENT_DATE and CURRENT_DATE <= i.expirydate and i.status = 'E') then
            for j in select pno, coid from coverage loop
                update rating_record
                set rate = rate + rate * Adj * 0.01
                where i.pno = j.pno and coid = j.coid;
            end loop;
        end if;
    --if position('abc abd' in 'abd ad ac abc') > 0 then
    --    countb := 100;
    --end if;
    end loop;
    return countb;
end;
$$ language plpgsql;

--10.The insurance company is to going to run a promotion campaign. If you buy a new policy (whether solely or jointly) and it is finally approved (i.e., the policy status becomes E), all other active and enforced policies that you are involved (including solely and jointly) will have their expiry dates extended by 30 calendar days. However, if any staff of the company is covered by the new policy, this promotion will not apply. Create a trigger (or triggers) to keep track when a policy status is changed to E and implement this promotion campaign accordingly.

create or replace view person_client(cid,pno) as
select c.cid, p.pno
from policy p, client c, insured_by i
where i.pno = p.pno and c.cid = i.cid
group by c.cid, p.pno;

create or replace view person_staff(pid,pno) as
select c.pid, p.pno
from policy p, client c, insured_by i, staff s
where i.pno = p.pno and c.pid = s.pid and c.cid = i.cid
group by p.pno, c.pid;

create function promotion() returns trigger
as $$
declare com_cid integer;
begin
    if(new.status = 'E' and new.pno not in (select pno from person_staff)) then
        select cl.cid into com_cid
        from client cl, insured_by ib
        where cl.cid = ib.cid and new.pno = ib.pno;
        update policy
        set expirydate = expirydate + interval '30 days'
        where pno in (select pno from person_client where (cid = com_cid) and (pno <> new.pno));
    end  if;
    return new;
end;
$$ language plpgsql;


create trigger promotion
after update on policy
for each row when (old.status is distinct from new.status) execute procedure promotion();



