from socket import *
import pickle
import sys
import time
import datetime
import threading
import types
from packet import Packet

'''
This function is to get the value of key, if we got its correspond value in a dictionary
k is one of keys
v is one of values
return key
'''
def get_key (dict, value):
    for k, v in dict.items():
        if v == value:
            return k
    return 0

'''
This function is to deal with repeat
Same returnMessage will be sent in too many situations
'''
def Wrong_type ():
    head = "client"
    returnMessage = Packet(head, "Sorry, wrong input type")
    return returnMessage

'''
This function is to deal with different require
1. timeout
2. check input is valid or not
3. logout
4. broadcast
5. message
6. block
7. unblock
8. whoelse
9. whoelsesince

serverName, TIMEOUT_INTERVAL, Port_Sock, Account_Port...(global variable and dict and list) can change here
mes is a lsit contains Username/Account_name and Password
Use currPort get a socket
receive message and send message to client
'''
def common(currPort):
    global serverName
    global TIMEOUT_INTERVAL
    global Port_Sock
    mes = list()
    global Account_Port
    global offlineMes
    global online_History
    global P2P_combination
    valid = False
    #get socket
    serverSocket = socket(AF_INET, SOCK_STREAM)
    serverSocket.bind((serverName, currPort))
    serverSocket.listen(0)
    print(currPort)
    connectionSocket, addr = serverSocket.accept()
    #account_block is an integer, if it adds to 3 will block this client
    account_block = 0
    global P2Pport
    while True:
        try:
            #receive message
            receivedMessage = connectionSocket.recv(2048)
        except timeout:
            #if timeout we have to close this socket and delete online record
            print("timeout")
            head = "server"
            #head.append("server")
            returnMessage = Packet(head, "Connection timeout!")
            connectionSocket.send(pickle.dumps(returnMessage))
            connectionSocket.close()
            #delete it from Account_Port and Port_Sock
            if len(mes) != 0:
                if mes[0] in Account_Port:
                    if Account_Port[mes[0]] in Port_Sock:
                        Port_Sock.pop(Account_Port[mes[0]])
                    Account_Port.pop(mes[0])
                    # this is the last time this account online
                    online_History[mes[0]] = datetime.datetime.now()
            return
        time.sleep(0.1)
        #if input is not valid yet
        if (not valid):
            mes = pickle.loads(receivedMessage)
            #if this account is online, login will be deny
            if mes[0] in Account_Port:
                head = "invalid"
                returnMessage = Packet(head, "This account already login")
                connectionSocket.send(pickle.dumps(returnMessage))
            
            else:
                #if account number and passward are valid, this client can get a connection
                if (mes[0] in account.keys() and mes[1] == account[mes[0]]):
                    Account_Port[mes[0]] = currPort
                    Port_Sock[currPort] = connectionSocket
                    print("Account valid")
                    account_block = 0
                    valid = True
                    head = "server " + mes[0]
                    returnMessage = Packet(head, "Welcome to message app!")
                    connectionSocket.send(pickle.dumps(returnMessage))
                    connectionSocket.settimeout(TIMEOUT_INTERVAL)
                    online_History[mes[0]] = datetime.datetime.now()
                #if account is not valid, count block number and tell this client to try again
                else:
                    account_block = account_block + 1
                    #we should block this account about 5 mins
                    if account_block == 3:
                        head = "warning "+str(duration)
                        string = "Sorry, you can't try to login in "
                        string = string + str(duration)
                        string = string + " seconds"
                        returnMessage = Packet(head, string)
                        connectionSocket.send(pickle.dumps(returnMessage))
                        time.sleep(duration)
                        account_block = 0
                    #let this client try again
                    else:
                        head = "invalid"
                        print("Wrong account number or pass word")
                        returnMessage = Packet(head, "Wrong account number or pass word. Please try again")
                        connectionSocket.send(pickle.dumps(returnMessage))
        #if valid
        else:
            Message = pickle.loads(receivedMessage)
            print(Message.get_info())
            MesList = Message.get_info().split(' ')
            #print(MesList)
            #if this client wanna to logout
            if(Message.get_info() == "logout"):
                head = "logout"
                returnMessage = Packet(head, "See you next time")
                connectionSocket.send(pickle.dumps(returnMessage))
                Port_Sock.pop(currPort)
                Account_Port.pop(mes[0])
                online_History[mes[0]] = datetime.datetime.now()
                valid = False
            #if this client wanna to broadcast
            elif(MesList[0] == "broadcast"):
                #print(Port_Sock)
                if len(MesList) == 2:
                    online_account = list()
                    names = list()
                    for (port,sck) in Port_Sock.items():
                        Account_name = get_key (Account_Port, port)
                        if currPort != port:
                            if Account_name in Blocks and Blocks[Account_name] == mes[0]:
                                #send this message to target
                                head = "client"
                                returnMessage = Packet(head, mes[0]+"(broadcast) send you a message")
                                sck.send(pickle.dumps(returnMessage))
                            else:
                                #if this account block you
                                head = "client"
                                Mess = Packet(head, mes[0] + "(broadcast): " + MesList[1])
                                sck.send(pickle.dumps(Mess))
                        online_account.append(Account_name)
                    for name in account:
                        if name not in online_account:
                            names.append(name)
                    #if this account is not online, will send this message after he login
                    head = "client"
                    returnMessage = Packet(head, "Can't send message to " + str(names) + ", because of not online")
                    connectionSocket.send(pickle.dumps(returnMessage))
                else:
                    connectionSocket.send(pickle.dumps(Wrong_type()))
            #if this client wanna to block someone
            elif(MesList[0] == "block"):
                #print(mes[0])
                #print(MesList[1])
                if len(MesList) == 2:
                    if mes[0] != MesList[1]:
                        Blocks[mes[0]] = MesList[1]
                        print(Blocks)
                        #block this account
                        head = "client"
                        returnMessage = Packet(head, MesList[1] + " already been blocked")
                        connectionSocket.send(pickle.dumps(returnMessage))
                    else:
                        #if this account wanna block himself
                        head = "client"
                        returnMessage = Packet(head, "Sorry, you can't block yourself")
                        connectionSocket.send(pickle.dumps(returnMessage))
                else:
                    connectionSocket.send(pickle.dumps(Wrong_type()))
            #if this client wanna to unblock someone
            elif(MesList[0] == "unblock"):
                if len(MesList) == 2:
                    if mes[0] != MesList[1]:
                        if (mes[0],MesList[1]) in Blocks.items():
                            Blocks.pop(mes[0])
                            #unblock target
                            head = "client"
                            returnMessage = Packet(head, MesList[1]+" already been unblocked")
                            connectionSocket.send(pickle.dumps(returnMessage))
                        else:
                            #if this account wanna to unblock someone who hasn't been block
                            head = "client"
                            returnMessage = Packet(head, "Sorry, "+MesList[1]+" hasn't been blocked")
                            connectionSocket.send(pickle.dumps(returnMessage))
                    else:
                        #if this account wanna to unblock himself
                        head = "client"
                        returnMessage = Packet(head, "Sorry, you can't unblock yourself")
                        connectionSocket.send(pickle.dumps(returnMessage))
                else:
                    connectionSocket.send(pickle.dumps(Wrong_type()))
            #if this client wanna to send message to someone
            elif MesList[0] == "message":
                if len(MesList) >= 3:
                    if MesList[1] in account:
                        if MesList[1] in Account_Port:
                            if (MesList[1], mes[0]) in Blocks.items():
                                #send message to someone but been locked
                                head = "client"
                                Mess = Packet(head, mes[0] + "(normal) send you a message")
                                sck = Port_Sock[Account_Port[MesList[1]]]
                                sck.send(pickle.dumps(Mess))
                            else:
                                #send message to someone
                                sck = Port_Sock[Account_Port[MesList[1]]]
                                head = "client"
                                list_M = MesList.copy()
                                list_M.pop(0)
                                list_M.pop(0)
                                string = ' '.join(list_M)
                                Mess = Packet(head, mes[0] + ": " + string)
                                sck.send(pickle.dumps(Mess))
                        else:
                            #send to someone who are not online
                            head = "client"
                            returnMessage = Packet(head, "This user isn't online, message will be sent after the user goes online")
                            connectionSocket.send(pickle.dumps(returnMessage))
                            info = list()
                            info.append(mes[0])
                            info.append(MesList[1])
                            info.append(MesList[2])
                            offlineMes.append(info)
                    else:
                        #send to someone not exist
                        head = "client"
                        returnMessage = Packet(head, "Sorry, this user doesn't exist")
                        connectionSocket.send(pickle.dumps(returnMessage))
                else:
                    connectionSocket.send(pickle.dumps(Wrong_type()))
            #to find out how many users online right now and who they are
            elif(MesList[0] == "whoelse"):
                name_str = "Online account:"
                if len(MesList) == 1:
                    if len(Account_Port) == 1:
                        #if there are nobody online
                        head = "client"
                        returnMessage = Packet(head, "No one else")
                        connectionSocket.send(pickle.dumps(returnMessage))
                    else:
                        #print who they are
                        for online_Acc in Account_Port:
                            if online_Acc != mes[0]:
                                name_str = name_str + " " + online_Acc
                        head = "client"
                        returnMessage = Packet(head, name_str)
                        connectionSocket.send(pickle.dumps(returnMessage))
                else:
                    connectionSocket.send(pickle.dumps(Wrong_type()))
            #to find out how many users online from given time and who they are
            elif(MesList[0] == "whoelsesince"):
                onlines = list()
                switch = False
                if(len(MesList) == 2):
                    since_name_str = "Those accounts were online " + MesList[1] + " seconds ago:"
                    if len(online_History) != 0:
                        if len(Account_Port) > 1:
                            for online_Acc in Account_Port:
                                if online_Acc != mes[0]:
                                    onlines.append(online_Acc)
                                    switch = True
                        for acc in online_History:
                            times = online_History[acc]
                            if times > datetime.datetime.now() - datetime.timedelta(seconds=int(MesList[1])):
                                if acc != mes[0] and acc not in onlines:
                                    since_name_str = since_name_str + " " + acc
                                    switch = True
                        for i in onlines:
                            since_name_str = since_name_str + " " + i
                        if switch == False:
                            #if no one online at that time(check by time - time)
                            head = "client"
                            returnMessage = Packet(head, "No one else")
                            connectionSocket.send(pickle.dumps(returnMessage))
                        else:
                            #just print them
                            head = "client"
                            returnMessage = Packet(head, since_name_str)
                            connectionSocket.send(pickle.dumps(returnMessage))
                    else:
                        #if no one online at that time(check by no one online before)
                        head = "client"
                        returnMessage = Packet(head, "No one else")
                        connectionSocket.send(pickle.dumps(returnMessage))
                else:
                    connectionSocket.send(pickle.dumps(Wrong_type()))
            #client want to get a p2p connection to another client        
            elif(MesList[0] == "startprivate"):
                #if he want to connection with himself
                if MesList[1] == mes[0]:
                    head = "client"
                    returnMessage = Packet(head, "Sorry you can't send private message to yourself")
                    connectionSocket.send(pickle.dumps(returnMessage))
                #if he was blocked by this client
                elif (MesList[1], mes[0]) in Blocks.items():
                    head = "client"
                    returnMessage = Packet(head, "Sorry you were blocked by him")
                    connectionSocket.send(pickle.dumps(returnMessage))
                else:
                    #A is client, user is server
                    if MesList[1] in Account_Port:
                        if len(P2P_combination) == 0:
                            head = "P2P-Client " + MesList[1]
                            returnMessage = Packet(head, P2Pport)
                            connectionSocket.send(pickle.dumps(returnMessage))
                            head = "P2P-Server " + mes[0]
                            returnMessage = Packet(head, P2Pport)
                            Port_Sock[Account_Port[MesList[1]]].send(pickle.dumps(returnMessage))
                            pair = list()
                            pair.append(mes[0])
                            pair.append(MesList[1])
                            P2P_combination.append(pair)
                        else:
                            #if this connection isn't the first one we have to check is there a connection between those two clients or not
                            for items in P2P_combination:
                                if (items[0] == mes[0] and items[1] == MesList[1]) or (items[1] == mes[0] and items[0] == MesList[1]):
                                    head = "client"
                                    returnMessage = Packet(head, "You already got a connection with him")
                                    connectionSocket.send(pickle.dumps(returnMessage))
                                else:
                                    head = "P2P-Client " + MesList[1]
                                    returnMessage = Packet(head, P2Pport)
                                    connectionSocket.send(pickle.dumps(returnMessage))
                                    head = "P2P-Server " + mes[0]
                                    returnMessage = Packet(head, P2Pport)
                                    Port_Sock[Account_Port[MesList[1]]].send(pickle.dumps(returnMessage))
                                    pair = list()
                                    pair.append(mes[0])
                                    pair.append(MesList[1])
                                    P2P_combination.append(pair)
                    else:
                        head = "client"
                        returnMessage = Packet(head, "This user isn't online")
                        connectionSocket.send(pickle.dumps(returnMessage))
            #elif(MesList[0] == "private"):
                P2Pport = P2Pport + 1
            elif(MesList[0] == "stopprivate"):
                for items in P2P_combination:
                    if (items[0] == mes[0] and items[1] == MesList[1]) or (items[1] == mes[0] and items[0] == MesList[1]):
                        P2P_combination.remove(items)                
            #if this users input some other words
            else:
                head = "client"
                returnMessage = Packet(head, "Can't understand sorry")
                connectionSocket.send(pickle.dumps(returnMessage))

'''
This function is to send some messages to someone just login
Those messages were sent to them when they are offline
Server will check all clients online or not at a certain frequency
'''
def offline():
    # start check
    while True:
        # gap is 1 second
        time.sleep(1)
        # go through all messages in offlineMes
        for info in offlineMes:
            # if receiver is online, send this message to him and delete this note in offlineMes(DICT)
            if info[1] in Account_Port:
                Send_P = Account_Port[info[1]]
                head = "offclient"
                returnMessage = Packet(head, info[0] + "(when you offline): " + info[2])
                Port_Sock[Send_P].send(pickle.dumps(returnMessage))
                offlineMes.pop(info)           

'''
Initialization
Name and prt of this server

currPort will give all socket different port
TIMEOUT_INTERVAL is how long to wait up to timeout (seconds)
valid is whether this account valid or not

Account_Port is a dictionary {[Account_name] -> [Port_number]}
Port_Sock is a dictionary {[Port_number] -> [Socket]}
account is a dictionary {[Username/Account_name] -> [Password]}
online_History is a dictionary {[Account_name] -> [online_time]}
blocks is a dictionary {[Account_name] -> [Account_name]},
first is who want to block and second is who was blocked
P2P_combination is a dictionary{[client] -> [server]}
offlineMes is a list contains some lists, those lists named info and contains :
1. who sent
2. who was sent
3. message information
'''

serverName = 'localhost'
serverPort = int(sys.argv[1])
duration = int(sys.argv[2])
TIMEOUT_INTERVAL = int(sys.argv[3]) #will timeout after xs

currPort = serverPort + 1
valid = False
#mes = list()
P2Pport = serverPort + 1000
Account_Port = dict()
Port_Sock = dict()
account = dict()
online_History = dict()
Blocks = dict()
P2P_combination = list()
offlineMes = list()

#Initialize account
account["hans"] = "falcon"
account["yoda"] = "wise"
account["vader"] = "sithlord"
account["r2d2"] = "socute"
account["c3p0"] = "droid"
account["leia"] = "blasterpistol"
account["obiwan"] = "jedimaster"
account["luke"] = "lightsaber"
account["chewy"] = "wookie"
account["palpatine"] = "darkside"

'''
account["admin1"] = "admin1"
account["admin2"] = "admin2"
account["admin3"] = "admin3"
account["admin4"] = "admin4"
account["admin5"] = "admin5"
account["admin6"] = "admin6"
account["admin7"] = "admin7"
account["admin8"] = "admin8"
account["admin9"] = "admin9"
account["admin10"] = "admin10"
'''

#Multi_thread implement offline function
offlineThreading = threading.Thread(target=offline)
offlineThreading.start()

serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind((serverName, serverPort))
serverSocket.listen(0)
#sys.exit()
#start server
while True:
    connectionSocket, addr = serverSocket.accept()
    #send port to client
    head = "port"
    Mess = Packet(head, str(currPort))
    connectionSocket.send(pickle.dumps(Mess))
    connectionSocket.close()
    #Multi_thread implement common function
    t1 = threading.Thread(target=common, args=(currPort,))
    t1.start()
    currPort += 1
