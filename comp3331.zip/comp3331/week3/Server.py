# Week3 Socket programming

from socket import *
sentence = 'Hello World'
serverName = 'localhost'
serverPort = 5000

# UDP socket and TCP socket
UDP_Socket = socket(AF_INET, SOCK_DGRAM)    # This an UDP Socket   AF_INET -> IPv4   SOCK_DGRAM -> UDP
TCP_Socket = socket(AF_INET, SOCK_STREAM)   # TCP socket

# Send data
# UDP
UDP_Socket.sendto(sentence.encode(), (serverName, serverPort)) # byte and string

# TCP
TCP_Socket.connect((serverName, serverPort))
TCP_Socket.send(sentence.encode())

# Receive data
# UDP
receivedMessage, serverAddress = UDP_Socket.recvfrom(2048)

# TCP
receivedMessage = TCP_Socket.recv(2048)

# Server
# UDP
serverSocket.bind(('', serverPort))

# TCP
serverSocket.bind(('', serverPort))
connectionSocket, addr = serverSocket.accept()   # Welcome socket and connection socket
