-- COMP3311 Prac 03 Exercise
-- Remove all tables in the company schema
-- The order of the statements is important

drop table WorksFor;
drop table DeptMissions;
drop table Departments;
drop table Employees;
