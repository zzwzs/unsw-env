import time
import datetime

print(time.time())
print(time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time())))


d1 = datetime.datetime.strptime('2012-03-05 18:41:30', '%Y-%m-%d %H:%M:%S')
d2 = datetime.datetime.strptime('2012-03-02 17:41:20', '%Y-%m-%d %H:%M:%S')
delta = d1 - d2
if d1 > d2 :
    print("             222                 ")
print(datetime.datetime.now() + datetime.timedelta(seconds=1))
print(datetime.datetime.now())
print(d1)
print (delta.days)

zzw = dict()
zzw[1] = "zzz"
if "zzz" in zzw.values():
    print(111)
    
    

