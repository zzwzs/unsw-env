create function rateChange(adj Integer)
  returns newRate table(rate float)   ---????
  as
      begin
        declare beforeRate float        ----????
        declare rate_curr cursor for  select rate from pnocoidview    ---??????
        open rate_curr                                          ----????
        fetch next from rate_curr into beforeRate   -----??????1????????????????beforeRate ?
        while (@@fetch_status = 0)    -----??????????
        begin
            insert  into newRate values(beforeRate * adj)  -- --??????(?rate??????????????)
            fetch next from rate_curr into beforeRate        ------??????1?
        end;
        close rate_curr        ---????
        deallocate rate_curr  --????
      end;
      
create view pnoview as
  select pno from policy where status='E' and CONVERT(varchar, effectivedata) >= CONVERT(varchar, GETDATE()) ----????
                                                                  and CONVERT(varchar, expirydata) >= CONVERT(varchar, GETDATE());
                                                                  
create view pnocoidview as
  select pno, coid, rate from pnoview, coverage where pnoview.pno=coverage.pno and coerage.coid=Rating_record.coid;
  
