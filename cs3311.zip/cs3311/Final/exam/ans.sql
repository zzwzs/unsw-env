-- COMP3311 20T1 Exam Answer Template
--
-- * Don't change view names;
-- * Only change the SQL code for view as commented below;
-- * and follow the order of the view arguments as stated in the comments (if any);
-- * and do not remove the ending semicolon of course.
--
-- * You may create additional views, if you wish;
-- * but you are not allowed to create tables.
--


-- Q1 to Q5 --
-- SQL queries
--


drop view if exists Q1;
create view Q1
as
-- replace the SQL code for view Q1(name, total) below:
select name, d.id, m.director_id, COUNT(m.id) as total from director d, movie m
where d.id = m.director_id
group by name
order by total desc, name asc
;

drop view if exists Q2_year_maxscore;
create view Q2_year_maxscore
as
select year, max(imdb_score) as imscore, id from movie m, rating r
where  year is not null and lang = 'English' and m.id = r.movie_id and r.num_voted_users >= 100000
group by year
order by year asc
;

drop view if exists Q2_list;
create view Q2_list
as
-- replace the SQL code for view Q2(year, title) below:
select year, title, r.imdb_score as imscore, lang, num_voted_users, r.movie_id, id from movie m, rating r
where year is not null and lang = 'English' and r.movie_id = m.id and r.num_voted_users >= 100000
order by year asc, title asc
;

drop view if exists Q2;
create view Q2
as
select year,title from Q2_list q where imscore = (select imscore from Q2_year_maxscore qym where qym.year = q.year);


drop view if exists Q3;
create view Q3
as
-- replace the SQL code for view Q3(name) below:
select a.name from actor a, acting ac, movie m, genre g
where a.id = ac.actor_id and ac.movie_id = m.id and g.movie_id = m.id
group by a.name
order by a.name
;
--(g.genre not like 'Crime' and g.genre not like 'Horror' and g.genre not like 'Mystery' and g.genre not like 'Sci-Fi' and g.genre not like 'Thriller')
drop view if exists Q3_except;
create temp view Q3_except
as
select a.name from actor a
where a.name not in Q3
group by a.name
order by a.name
;

drop view if exists Q4_list;
create view Q4_list
as
-- replace the SQL code for view Q4(name) below:
select a.name, g.genre, a.facebook_likes, count(distinct(genre)) as gnum from actor a, acting ac, movie m, genre g
where a.id = ac.actor_id and ac.movie_id = m.id and g.movie_id = m.id
group by a.name
;

drop view if exists Q4;
create view Q4
as
select name, facebook_likes from Q4_list
where gnum >= 18
order by facebook_likes desc, name asc
;

drop view if exists Q5;
create view Q5
as
-- replace the SQL code for view Q5(title, name) below:
select title, d.name from movie m, director d, actor a, acting ac
where d.name = a.name and d.id = m.director_id and a.id = ac.actor_id and ac.movie_id = m.id
order by title asc, d.name asc
;



-- Q6 --
--

drop view if exists Q6a;
create view Q6a
as
-- replace "REPLACE ME" with your answer below (e.g. select "A,BC"):
select "BC"
;

drop view if exists Q6b;
create view Q6b
as
-- replace "REPLACE ME" with your answer below (e.g. select "A,BC"):
select "A"
;

drop view if exists Q6c;
create view Q6c
as
-- replace "REPLACE ME" with your answer below (e.g. select "A,BC"):
select "ACE,CDE"
;



-- Q7 --
--

drop view if exists Q7a;
create view Q7a
as
-- replace "REPLACE ME" with your answer below (e.g. select "AB,BCD,EFG"):
select "ABCD,AEFG"
;

drop view if exists Q7b;
create view Q7b
as
-- replace "REPLACE ME" with your answer below (e.g. select "AB,BCD,EFG"):
select "AC,DEF,ABDG"
;

drop view if exists Q7c;
create view Q7c
as
-- replace "REPLACE ME" with your answer below (e.g. select "AB,BCD,EFG"):
select "ABCD,AFG"
;



-- Q8 --
--

drop view if exists Q8a;
create view Q8a
as
-- replace "REPLACE ME" with your answer below (e.g. select "Y" for serializable, select "N" otherwise):
select "Y"
;

drop view if exists Q8b;
create view Q8b
as
-- replace "REPLACE ME" with your answer below (e.g. select "Y" for serializable, select "N" otherwise):
select "N"
;

drop view if exists Q8c;
create view Q8c
as
-- replace "REPLACE ME" with your answer below (e.g. select "Y" for serializable, select "N" otherwise):
select "Y"
;

drop view if exists Q8d;
create view Q8d
as
-- replace "REPLACE ME" with your answer below (e.g. select "Y" for serializable, select "N" otherwise):
select "N"
;



-- Q9 --
--

drop view if exists Q9;
create view Q9
as
-- replace "REPLACE ME" with your answer below (e.g. select "A" for choice A):
select "A"
;



-- 10 --
--

drop view if exists Q10;
create view Q10
as
-- replace "REPLACE ME" with your answer below (e.g. select "A" for choice A):
select "C"
;



-- END OF EXAM --
--
