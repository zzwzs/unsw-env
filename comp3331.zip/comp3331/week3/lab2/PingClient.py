'''
Python3
'''

import socket
import time
import sys
  
IP = sys.argv[1]
port = sys.argv[2]
times = []
for i in range(0,10):
    #message want to print out
    #message = "Success. This is {} ping\r\n".format(i)
    message = "PING {} {}\r\n".format(i, int(time.time()))
    #Return the time in seconds since the epoch as a floating point number
    time1 = time.time()
    # default encoding to utf-8
    message = message.encode()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(1)
    sock.sendto(message, (IP, int(port)))
    reply = True
    try:
        receive = sock.recvfrom(1024)
    except Exception as exception:
        reply = False
    #get the time after receive
    time2 = time.time()
    #if we got reply
    if reply == True:
        print ("ping to {}, seq = {}, rtt = {:.2f} ms".format(IP, i+1, (time2 - time1) * 1000))
        times.append((time2 - time1) * 1000)
    #if we can't get reply
    if reply == False:
        print ("ping to {}, seq = {}, rtt = Timeout".format(IP, i))

#find average round-trip delay time
n = 0
for i in range(len(times)):
    n += times[i]

    
print("Average rtt is {:.2f} ms".format(n/len(times)))
print("Max rtt is {:.2f} ms".format(max(times)))
print("Min rtt is {:.2f} ms".format(min(times)))

