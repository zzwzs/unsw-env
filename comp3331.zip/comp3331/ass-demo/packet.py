'''
This class is a packet was sent between client and server
This packet will have a head part and a body part
Head part will determine what job this packet act
Body part will determine what thing this packet will do
'''

class Packet ():

    def __init__ (self, head, info):
        self._head = head
        self._info = info
        
    # function to get head
    def get_head(self):
        return self._head
    
    #function to get body part   
    def get_info(self):
        return self._info
