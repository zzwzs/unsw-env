create or replace view pc(coid, pno, cname) as
select c.coid, p.pno, c.cname
from policy p, coverage c
where p.pno = c.pno
order by p.pno
;

create or replace view concate_Policy(pno, cname) AS
select pno, array_to_string(array_agg(cname), ',')
from pc
group by pno
order by pno
;

create or replace view template(pno, npolicies) as
select *
from concate_Policy
order by pno
;

create table result as select * from template;

create or replace function 
      insert_table()
      returns void
as $$
declare
    cp_element record;
    pc_element record;
    num integer := 0;
    contain integer := 0;
    last_cp_element integer := 0;    
    last_pc_element integer := 0; 
    Previous_pno integer := 10000;
begin
    for cp_element in select pno, cname from concate_Policy loop
        last_cp_element := last_cp_element + 1;
        for pc_element in select pno, cname from pc loop
            last_pc_element := last_pc_element + 1;
            if cp_element.pno <> pc_element.pno then
                if Previous_pno <> pc_element.pno and Previous_pno <> 10000 and contain = 0 then 
                    num := num + 1;
                end if;
                if Previous_pno <> pc_element.pno and Previous_pno <> 10000 and contain = 1 then
                    contain := 0;
                end if;
                if position(pc_element.cname in cp_element.cname) > 0 then 
                else
                    contain := 1;
                end if;
                if last_pc_element = (select count(*) from pc) then
                    if contain = 0 then
                        num := num + 1;
                    else
                        contain := 0;
                    end if;
                end if;
                if last_cp_element = (select count(*) from concate_Policy) and last_pc_element = (select count(*) from pc) - (select count(*) from pc where pno = pc_element.pno) then
                    if contain = 0 then
                        num := num + 1;
                    else
                        contain := 0;
                    end if;
                end if;
                Previous_pno := pc_element.pno;
            end if;
         end loop;
         last_pc_element := 0;
         Previous_pno := 10000;
         contain := 0;       
         update result
         set npolicies = num
         where pno = cp_element.pno;
         num := 0;
     end loop;

end;
$$ language plpgsql;               

select insert_table();

create or replace view Q8(pno, npolicies) as
select *
from result
;
