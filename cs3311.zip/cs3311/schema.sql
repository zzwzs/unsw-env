-- COMP3311 Prac 03 Exercise
-- Schema for simple company database

create table Employees (
	tfn         char(11) check(tfn ~ '\d\d\d-\d\d\d-\d\d\d'),
	givenName   varchar(30) not null,
	familyName  varchar(30),
	hoursPweek  float check (hoursPweek <= 168 AND hoursPweek >= 0),
	primary key (tfn)
);

create table Departments (
	id          char(3) check(id ~ '\d\d\d') not null,
	name        varchar(100) UNIQUE,
	manager     char(11) UNIQUE,
	primary key (id),
    foreign key (manager) references Employees(tfn)
	
);

create table DeptMissions (
	department  char(3),
	keyword     varchar(20) not null,
    foreign key (department) references Departments(id)
);

create table WorksFor (
	employee    char(11),
	department  char(3) not null,
	percentage  float check (percentage > 0 AND percentage <= 100),
	foreign key (employee) references Employees(tfn),
    foreign key (department) references Departments(id)
);
