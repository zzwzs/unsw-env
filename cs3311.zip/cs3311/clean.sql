-- COMP3311 Prac 03 Exercise
-- Remove all data from the company schema
-- Leaves four empty tables
-- The order of the statements is important

delete from WorksFor;
delete from DeptMissions;
delete from Departments;
delete from Employees;
