import pandas as pd
import numpy as np
from sklearn import tree
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

pd.DataFrame({"A": [1, 2], "B": [3, 4]}).to_numpy()
