from socket import *
import pickle
import time
import threading
import sys
from packet import Packet
'''
Initialization
valid : account and password are correct or not
messageSize : the size of message was received
Gap : client should wait for server start
blocked : 3 times wrong input(account and password) will be blocked
username is the account number(string)
P2P_connections is a dictionary {[this user name + ' ' + target] -> [socket]}
duration is the time the account must be blocked
'''
serverName = sys.argv[1]
serverPort = int(sys.argv[2])
valid = False
messageSize = 2048
Gap = 0.2
blocked = False
username = ''
P2P_connections = dict()
duration = int()

'''
This function is a thread for receive
If this client becomes a 'server' or 'client' it should call this function to receive message
If someone who got connection with this client want to stop this connection, it will send a message to this client too
'''
def receivedP2PF(target):
    global P2P_connections
    global valid
    global username
    while valid == True:
        dictionary = P2P_connections.copy()
        #find the socket in dictionary and then receive messages
        sokt = dictionary[target]
        receiveP2P = sokt.recv(messageSize)
        receiveP2P = pickle.loads(receiveP2P)
        #if someone want to stop connection with this client
        if receiveP2P.get_head() == "Delete_P2P":
            delete(receiveP2P.get_info())
        else:
            #if someone send message to this client
            from_ppl = receiveP2P.get_head().split(' ')
            print(from_ppl[1] + "(private): " + receiveP2P.get_info())
            #break

'''
This function is to delete connection in dictionary
'''                    
def delete(target):
    global P2P_connections
    global username
    for i in P2P_connections:
        j = i.split(' ')
        if (j[0] == username and j[1] == target) or (j[1] == username and j[0] == target):
            #print(P2P_connections[i])
            socks = P2P_connections[i]
            P2P_connections.pop(i)
            print("Connection with "+target+" closed")
            break
    #socks.close()
'''
This function was implemented by Multi_thread
TCP_Socket : Socket between this client and server
valid : This account is valid or not (change this variable here depends on server)
blocked : 3 times wrong input will block this client(depends on server message)
'''
def receiveFunction():
    global TCP_Socket
    global valid
    global blocked
    global username
    global P2P_connections
    global duration
    while True:
        # receive message
        receivedMessage = TCP_Socket.recv(messageSize)
        receivedMessage = pickle.loads(receivedMessage)
        
        print(receivedMessage.get_info())
        # if this message is about valid or not
        if "server" in receivedMessage.get_head():
            #if this message means valid
            if ('Welcome' in receivedMessage.get_info()):
                valid = True
                reMes = receivedMessage.get_head().split(" ")
                username = reMes[1]
                #print(username)
            #if this message means timeout
            if ('Connection timeout!' in receivedMessage.get_info()):
                valid = False
                TCP_Socket.close()
                return
        #if this message means 3 times wrong input
        if "warning" in receivedMessage.get_head():
            listA = receivedMessage.get_head().split(' ')
            duration = int(listA[1])
            blocked = True
        
        if "P2P-Client" in receivedMessage.get_head():
            head_mes = receivedMessage.get_head().split(" ")
            time.sleep(1)
            peer = threading.Thread(target=clientThread, args=(receivedMessage.get_info(), head_mes[1],))
            peer.start()
            print('Connection completed')
        if "P2P-Server" in receivedMessage.get_head():
            head_mes = receivedMessage.get_head().split(" ")
            peer = threading.Thread(target=serverThread, args=(receivedMessage.get_info(), head_mes[1],))
            peer.start()
            print(head_mes[1]+" got a connection with you")

'''
This function will be implement when server let this client to be a 'client'(in p2p connection)
string is the key in dictionary
timeout_interval is how long the socket exist
will call receivedP2PF to receive messages
'''
def clientThread(RMI, Object):
    global P2P_connections
    global username
    string = username+' '+Object
    TIMEOUT_INTERVAL = 1000
    P2PC_Socket = socket(AF_INET, SOCK_STREAM)
    P2PC_Socket.connect((serverName, RMI))
    P2PC_Socket.settimeout(TIMEOUT_INTERVAL)
    P2P_connections[string] = P2PC_Socket
    t2 = threading.Thread(target=receivedP2PF, args=(string, ))
    t2.start()
    #print(P2PC_Socket)
    '''while True:
        message = input()
        MesList = message.split(' ')
        if MesList[0] == "private":
            a = 1'''
            
'''
This function will be implement when server let this client to be a 'server'(in p2p connection)
string is the key in dictionary
timeout_interval is how long the socket exist
will call receivedP2PF to receive messages
'''
def serverThread(RMI, Object):
    global username
    global P2P_connections
    string = username+' '+Object
    TIMEOUT_INTERVAL = 1000
    P2PS_Socket = socket(AF_INET, SOCK_STREAM)
    P2PS_Socket.bind((serverName, RMI))
    P2PS_Socket.listen(0)
    connectionSocket, addr = P2PS_Socket.accept()
    connectionSocket.settimeout(TIMEOUT_INTERVAL)
    P2P_connections[string] = connectionSocket
    t2 = threading.Thread(target=receivedP2PF, args=(string, ))
    t2.start()

# establish connection
TCP_Socket2 = socket(AF_INET, SOCK_STREAM)
TCP_Socket2.connect((serverName, serverPort))
# receive messages
receivedMessage = TCP_Socket2.recv(messageSize)
receivedMessage = pickle.loads(receivedMessage)
# get port number
currPort = int(receivedMessage.get_info())
print(currPort)
TCP_Socket2.close()
# wait for sever start
time.sleep(Gap)
TCP_Socket = socket(AF_INET, SOCK_STREAM)
TCP_Socket.connect((serverName, currPort))
# Multi-threaded (for receive messages)
t1 = threading.Thread(target=receiveFunction)
t1.start()

# start client
while True:
    # wait for check valid change
    time.sleep(Gap)
    if (not valid):
        # check should block now or not
        if blocked == True:
            print("Please wait for some seconds")
            time.sleep(duration)
            blocked = False
        # get check valid information
        validInfo = []
        validInfo.append(input("Username: "))
        validInfo.append(input("Password: "))
        # send account number adn password to server
        TCP_Socket.send(pickle.dumps(validInfo))
    else:
        # if this account already been checked and valid
        message = input()
        MesList = message.split(' ')
        if message == "logout":
            # if client want to logout
            head = "client"
            messages = Packet(head, message)
            TCP_Socket.send(pickle.dumps(messages))
            valid = False
            dele = list()
            for i in P2P_connections.keys():
                j = i.split(' ')
                if username in j:
                    dele.append(i)
                    continue
            for i in dele:
                if i in P2P_connections:
                    P2P_connections.pop(i)
        #print(mes)
        #if tgus account want to send private message to another client
        elif MesList[0] == "private":
            if len(MesList) >= 3:
                if MesList[1] == username:
                    print("Sorry, you can't send private to yourself")
                else:
                    #this switch is whether this client got a connection with target or not
                    switch = False
                    for ppl in P2P_connections:
                        ppls = ppl.split(' ')
                        if ppls[0] == username and ppls[1] == MesList[1]:
                            sokt = P2P_connections[ppl]
                            head = "p2p " + validInfo[0]
                            String = MesList.copy()
                            String.pop(0)
                            String.pop(0)
                            sentence = ' '.join(String)
                            messages = Packet(head, sentence)
                            sokt.send(pickle.dumps(messages))
                            switch = True
                    if switch == False:
                        print("you have not executed startprivate to him")
            else:
                print("Sorry, wrong format")
        #if this account want to close the connection between itself and another client
        elif MesList[0] == "stopprivate":
            switch = False
            #tell server this connect will be closed
            head = "p2p"
            message = Packet(head,"stopprivate "+MesList[1])
            TCP_Socket.send(pickle.dumps(message))
            for pair in P2P_connections:
                single = pair.split(' ')
                if (single[0] == username and single[1] == MesList[1]) or (single[0] == MesList[1] and single[1] == username):
                    #tell target this connection will be closed
                    head = "Delete_P2P"
                    messages = Packet(head, username)
                    P2P_connections[pair].send(pickle.dumps(messages))
                    #print(P2P_connections[pair])
                    socks = P2P_connections[pair]
                    P2P_connections.pop(pair)
                    switch = True
                    print("Connection closed")
                    break
            #if there is no connection between this client and target
            if switch == False:
                print("Sorry, we can't find connection between you and "+MesList[1])
            socks.close()
        #send message to server
        else:
            head = "client"
            messages = Packet(head, message)
            TCP_Socket.send(pickle.dumps(messages))
