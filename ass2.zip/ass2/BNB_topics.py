import pandas as pd
import sys
import numpy as np
from sklearn.naive_bayes import BernoulliNB

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report



train = pd.read_csv(sys.argv[1], sep='\n', header=None)
tests = pd.read_csv(sys.argv[2], sep='\n', header=None)
trains = []
labels = []

test = []

delete_uml = []

numebrs = []

stop = 0

for string in train.to_numpy():
    s = string[0].replace('\t',' ')
    t = s.split(' ')
    labels.append(t[-3])
    for i in t:
        if i.startswith('https://') or i.startswith('http://'):
            delete_uml.append(i)
        
    for i in delete_uml:
        if i in t:
            t.remove(i)
    numbers.append(t[0])
    t.pop(0)
    s = ' '.join(t)
    s = s.replace('!','')
    s = s.replace('.', '')
    s = s.replace(',', '')
    s = s.replace('?', '')
    s = s.replace('-', '')
    s = s.replace('“', '')
    s = s.replace('”', '')
    s = s.replace('|', '')
    s = s.replace('/', ' ')
    s = s.replace('&', ' ')
    s = s.replace(':', ' ')
    s = s.replace("'", ' ')
    s = s.replace(';', ' ')
    s = s.replace('[', ' ')
    s = s.replace('{', ' ')
    s = s.replace(']', ' ')
    s = s.replace('}', ' ')
    s = s.replace('*', ' ')
    s = s.replace('~', ' ')
    s = s.replace('\\\\', ' ')
    s = s.replace('(', ' ')
    s = s.replace(')', ' ')
    s = s.replace('+', ' ')
    s = s.replace('=', ' ')
    s = s.replace('<', ' ')
    s = s.replace('>', ' ')
    
    #if 'positive' in string[0]:
    #    labels.append('positive')
    #if 'negative' in string[0]:
    #    labels.append('negative')
    #if 'neutral' in string[0]:
    #    labels.append('neutral')

    trains.append(s)
#print(trains[2])
#print(labels)
labels_t = []
delete_uml_t = []

for string in tests.to_numpy():
    s1 = string[0].replace('\t',' ')
    t1 = s1.split(' ')
    labels_t.append(t1[-3])
    for i in t1:
        if i.startswith('https://') or i.startswith('http://'):
            delete_uml_t.append(i)
        
    for i in delete_uml_t:
        if i in t1:
            t1.remove(i)
    t1.pop(0)
    s1 = ' '.join(t1)
    s1 = s1.replace('!','')
    s1 = s1.replace('.', '')
    s1 = s1.replace(',', '')
    s1 = s1.replace('?', '')
    s1 = s1.replace('-', '')
    s1 = s1.replace('“', '')
    s1 = s1.replace('”', '')
    s1 = s1.replace('|', '')
    s1 = s1.replace('/', ' ')
    s1 = s1.replace('&', ' ')
    s1 = s1.replace(':', ' ')
    s1 = s1.replace("'", ' ')
    s1 = s1.replace(';', ' ')
    s1 = s1.replace('[', ' ')
    s1 = s1.replace('{', ' ')
    s1 = s1.replace(']', ' ')
    s1 = s1.replace('}', ' ')
    s1 = s1.replace('*', ' ')
    s1 = s1.replace('~', ' ')
    s1 = s1.replace('\\\\', ' ')
    s1 = s1.replace('(', ' ')
    s1 = s1.replace(')', ' ')
    s1 = s1.replace('+', ' ')
    s1 = s1.replace('=', ' ')
    s1 = s1.replace('<', ' ')
    s1 = s1.replace('>', ' ')
    
    #if 'positive' in string[0]:
    #    labels.append('positive')
    #if 'negative' in string[0]:
    #    labels.append('negative')
    #if 'neutral' in string[0]:
    #    labels.append('neutral')

    test.append(s1)
#print(trains[2])
#print(labels)

cv = CountVectorizer()
cv_fit=cv.fit_transform(trains) 
#print(train.to_numpy())

#print(cv.get_feature_names())
#print(len(labels))

X = cv_fit.toarray()
Y = labels
clf = BernoulliNB()
clf = clf.fit(X, Y)

test_p = cv.transform(test).toarray()

list_t = clf.predict(test_p)

j = 0
for i in numbers:
    if j>=500 :
        break;
    print(i + ' ' + list_t[j])
    j = j + 1

#print(clf.predict(test1))
#print(clf.predict(test2))
#predicted_y = model.predict(X_test)
#print(y_test, predicted_y)
#print(clf.predict_proba(X_test))
#print(accuracy_score(y_test, predicted_y))
#print(precision_score(y_test, predicted_y))
#print(recall_score(y_test, predicted_y))
#print(f1_score(y_test, predicted_y, average='micro'))
#print(f1_score(y_test, predicted_y, average='macro'))
#print(classification_report(y_test, predicted_y))
#print(clf.predict([[2., 2.]]))

