from socket import *
import pickle
import sys
import time
import threading
import types
from packet import Packet

def get_key (dict, value):
    for k, v in dict.items():
        if v == value:
            return k
    return 0


def comm(currPort):
    global serverName
    global TIMEOUT_INTERVAL
    global allClients
    mes = list()
    global Account_Port
    global offlineMes
    valid = False
    serverSocket = socket(AF_INET, SOCK_STREAM)
    serverSocket.bind((serverName, currPort))
    serverSocket.listen(0)
    print(currPort)
    connectionSocket, addr = serverSocket.accept()
    allClients[currPort] = connectionSocket
    #receive data
    while True:
        try:
            receivedMessage = connectionSocket.recv(2048)
        except timeout:
            print("timeout")
            returnMessage = "Connection timeout!"
            connectionSocket.send(returnMessage.encode())
            connectionSocket.close()
            return
        time.sleep(0.1)
        if (not valid):
            mes = pickle.loads(receivedMessage)
            Account_Port[mes[0]] = currPort
            if (mes[0] in account.keys() and mes[1] == account[mes[0]]):
                print("Account valid")
                valid = True
                returnMessage = "Welcome to message app!"
                connectionSocket.send(returnMessage.encode())
                connectionSocket.settimeout(TIMEOUT_INTERVAL)
            else:
                print("Wrong account number or pass word")
                returnMessage = "Wrong account number or pass word. Please try again"
                connectionSocket.send(returnMessage.encode())
        else:
            Message = receivedMessage.decode()
            MesList = Message.split(' ')
            #print(MesList)
            if(Message == "logout"):
                returnMessage = "See you next time"
                connectionSocket.send(returnMessage.encode())
                allClients.pop(currPort)
                Account_Port.pop(mes[0])
                valid = False
            elif(MesList[0] == "broadcast"):
                #print(allClients)
                if len(MesList) == 2:
                    online_account = list()
                    names = list()
                    for (port,sck) in allClients.items():
                        Account_name = get_key (Account_Port, port)
                        if currPort != port:
                            if Account_name in Blocks and Blocks[Account_name] == mes[0]:
                                returnMessage = mes[0]+" send you a message"
                                sck.send(returnMessage.encode())
                            else:
                                Mess = mes[0] + "(broadcast): " + MesList[1] 
                                sck.send(Mess.encode())
                        online_account.append(Account_name)
                    for name in account:
                        if name not in online_account:
                            names.append(name)
                    returnMessage = "Can't send message to " + str(names) + ", because of not online"
                    connectionSocket.send(returnMessage.encode())
                else:
                    returnMessage = "Sorry, wrong input type"
                    connectionSocket.send(returnMessage.encode())
            elif(MesList[0] == "block"):
                #print(mes[0])
                #print(MesList[1])
                if len(MesList) == 2:
                    if mes[0] != MesList[1]:
                        Blocks[mes[0]] = MesList[1]
                        print(Blocks)
                        returnMessage = MesList[1] + " already been blocked"
                        connectionSocket.send(returnMessage.encode())
                    else:
                        returnMessage = "Sorry, you can't block yourself"
                        connectionSocket.send(returnMessage.encode())
                else:
                    returnMessage = "Sorry, wrong input type"
                    connectionSocket.send(returnMessage.encode())
            elif(MesList[0] == "unblock"):
                if len(MesList) == 2:
                    if mes[0] != MesList[1]:
                        if (mes[0],MesList[1]) in Blocks.items():
                            Blocks.pop(mes[0])
                            returnMessage = MesList[1]+" already been unblocked"
                            connectionSocket.send(returnMessage.encode())
                        else:
                            returnMessage = "Sorry, "+MesList[1]+" hasn't been blocked"
                            connectionSocket.send(returnMessage.encode())
                    else:
                        returnMessage = "Sorry, you can't unblock yourself"
                        connectionSocket.send(returnMessage.encode())
                else:
                    returnMessage = "Sorry, wrong input type"
                    connectionSocket.send(returnMessage.encode())               
            elif MesList[0] == "message":
                if len(MesList) == 3:
                    if MesList[1] in account:
                        if MesList[1] in Account_Port:
                            sck = allClients[Account_Port[MesList[1]]]
                            Mess = mes[0] + ": " + MesList[2]
                            sck.send(Mess.encode())
                        else:
                            returnMessage = "This user isn't online, message will be sent after the user goes online"
                            connectionSocket.send(returnMessage.encode())
                            info = list()
                            info.append(mes[0])
                            info.append(MesList[1])
                            info.append(MesList[2])
                            offlineMes.append(info)
                    else:
                        returnMessage = "Sorry, this user doesn't exist"
                        connectionSocket.send(returnMessage.encode())
                else:
                    returnMessage = "Sorry, wrong input type"
                    connectionSocket.send(returnMessage.encode())
            elif(MesList[0] == "whoelse"):
                name_str = "Online account:"
                if len(MesList) == 1:
                    if len(Account_Port) == 0:
                        returnMessage = "No one else"
                        connectionSocket.send(returnMessage.encode())
                    else:
                        for online_Acc in Account_Port:
                            if online_Acc != mes[0]:
                                name_str = name_str + " " + online_Acc
                        returnMessage = name_str
                        connectionSocket.send(returnMessage.encode())
                else:
                    returnMessage = "Sorry, wrong input type"
                    connectionSocket.send(returnMessage.encode())
            elif(MesList[0] == "whoelsesince"):
                a = 1
            else:
                returnMessage = "Can't understand sorry"
                connectionSocket.send(returnMessage.encode())

def offline():
    while True:
        time.sleep(1)
        for info in offlineMes:
            if info[1] in Account_Port:
                Send_P = Account_Port[info[1]]
                returnMessage = info[0] + "(when you offline): " + info[2]
                allClients[Send_P].send(returnMessage.encode())
                offlineMes.pop(info)           

def command():
    global allClients
    global valid
    while True:
        command = input()
        print(command)
        if (command[0] == "broadcast"):
            #print(command[2:])
            for socket in list(allClients.values()):
                socket.send(command[2:].encode())
        if (command[0] == "message"):
            argv = command.split(" ")
            socket = allClients[int(argv[1])]
            socket.send(argv[2].encode())
serverName = 'localhost'
serverPort = int(sys.argv[1])
currPort = serverPort + 1
TIMEOUT_INTERVAL = 600
valid = False
#mes = list()
Account_Port = dict()
allClients = dict()
account = dict()
offlineMes = list()

account["admin1"] = "admin1"
account["admin2"] = "admin2"
account["admin3"] = "admin3"
account["admin4"] = "admin4"
account["admin5"] = "admin5"
account["admin6"] = "admin6"
account["admin7"] = "admin7"
account["admin8"] = "admin8"
account["admin9"] = "admin9"
account["admin10"] = "admin10"

commandThreading = threading.Thread(target=command)
commandThreading.start()

offlineThreading = threading.Thread(target=offline)
offlineThreading.start()
Blocks = dict()

serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind((serverName, serverPort))
serverSocket.listen(0)
#sys.exit()
while True:
    connectionSocket, addr = serverSocket.accept()
    connectionSocket.send(str(currPort).encode())
    connectionSocket.close()
    t1 = threading.Thread(target=comm, args=(currPort,))
    t1.start()
    currPort += 1
