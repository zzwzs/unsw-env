class Packet ():

    def __init__ (self, head, info):
        self._head = head
        self._info = info
        
    def get_head(self):
        return self._head
        
    def get_info(self):
        return self._info
