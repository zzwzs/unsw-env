
## STUDENT ID: FILL IN YOUR ID
## STUDENT NAME: FILL IN YOUR NAME


## Question 2

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)       # make sure you run this line for consistency 
x = np.random.uniform(1, 2, 100)
y = 1.2 + 2.9 * x + 1.8 * x**2 + np.random.normal(0, 0.9, 100)
plt.scatter(x,y)
plt.show()

## (c)

# YOUR CODE HERE
def loss_function(X,y,w0,w1,C):
    n = X.shape[0] # Get the number of samples
    loss = 0
    for i in range(n):
        loss = loss + np.sqrt(1/C**2*(y[i]-(w0+w1*x[i]))**2+1)-1
    return loss

def Gradient_descent(X,y,max_pass=100,alpha=1e-2,C=2):
    n = X.shape[0] # Get the number of samples
    w1 = 1
    w0 = 1 # Initialize b=0
    loss_list = []
    
    #iterations, each round of iteration will fit all the data in the sample.
    for iter_t in range(max_pass): 
        #print('iteration num:',iter_t)
        w0_g = 0
        w1_g = 0
        for i in range(n):
            w0_g = w0_g + 1/np.sqrt(1/C**2*(y[i]-(w0+w1*x[i]))**2+1)*1/C**2*(y[i]-(w0+w1*x[i]))*(-1)
            w1_g = w1_g + 1/np.sqrt(1/C**2*(y[i]-(w0+w1*x[i]))**2+1)*1/C**2*(y[i]-(w0+w1*x[i]))*(-x[i])
        w0 = w0 - alpha*w0_g
        w1 = w1 - alpha*w1_g

        loss_list.append(loss_function(X,y,w0,w1,C))

    return w0,w1,loss_list



## plotting help
alphas = [10e-1, 10e-2, 10e-3,10e-4,10e-5,10e-6,10e-7, 10e-8, 10e-9]
losses = [[] for i in range(len(alphas))]

for idx in range(len(alphas)):
    w0,w1,losses[idx] = Gradient_descent(x,y,max_pass=100,alpha=alphas[idx],C=2)

fig,ax = plt.subplots(3,3, figsize=(10,10))
for i, ax_i in enumerate(ax.flat):
    # losses is a list of 9 elements. Each element is an array of length 100 storing the loss at each iteration for that particular step size
    ax_i.plot(losses[i])         
    ax_i.set_title(f"step size: {alphas[i]}")    # plot titles  

plt.tight_layout()      # plot formatting
plt.savefig('grid_plot.png')
plt.show()


# (e)
def Gradient_descent2(X,y,max_pass=100,alpha=1e-2,C=2):
    n = X.shape[0] # Get the number of samples
    w1 = 1
    w0 = 1 # Initialize b=0
    loss_list = []
    
    plt.figure()
    
    #iterations, each round of iteration will fit all the data in the sample.
    for iter_t in range(max_pass): 
        #print('iteration num:',iter_t)
        w0_g = 0
        w1_g = 0
        for i in range(n):
            w0_g = w0_g + 1/np.sqrt(1/C**2*(y[i]-(w0+w1*x[i]))**2+1)*1/C**2*(y[i]-(w0+w1*x[i]))*(-1)
            w1_g = w1_g + 1/np.sqrt(1/C**2*(y[i]-(w0+w1*x[i]))**2+1)*1/C**2*(y[i]-(w0+w1*x[i]))*(-x[i])
        w0 = w0 - alpha*w0_g
        w1 = w1 - alpha*w1_g

        loss_list.append(loss_function(X,y,w0,w1,C))
        
        plt.plot(w0,w1,'*')
    
    plt.show()

    return w0,w1,loss_list

w0,w1,losses[idx] = Gradient_descent2(x,y,max_pass=100,alpha=0.001,C=2)

y_pred = w0+w1*x
plt.figure()
plt.scatter(x,y)
plt.scatter(x,y_pred)
plt.show()


## Question 3

# (a)

X = np.array([[-0.8,1],[3.9,0.4],[1.4,1],[0.1,-3.3],[1.2,2.7],[-2.45,0.1],[-1.5,-0.5],[1.2,-1.5]])
y = np.array([1,-1,1,-1,-1,-1,1,1])

plt.figure()
plt.plot(X[y==-1,0],X[y==-1,1],'*')
plt.plot(X[y==1,0],X[y==1,1],'o')
plt.show()

# (c)
# YOUR CODE HERE
def perceptron(X,y,max_pass,mu=0.2):
    
    n = X.shape[0] # Get the number of samples
    w = np.ones(X.shape[1]) # Initialize weights to 1
    b = 1
    iter_t = 1
   
    while True:
        print('iteration num:',iter_t)
        mistake_i = 0
        for i in range(n): # Calculate with every data in the datasets
            loss_i = y[i]*(np.dot(X[i,:],w)+b)
            if loss_i<=0:
                w += mu*y[i]*X[i,:]
                b += mu*y[i]
                mistake_i += 1
        print(b,w)
        if mistake_i==0:
            break
        else:
            iter_t = iter_t+1
    
    return w,b

X_kernel = np.array([X[:,0]**2,X[:,1]**2,np.sqrt(2)*X[:,0]*X[:,1]]).T
perceptron(X_kernel,y,max_pass=100,mu=0.2)


# Question 5

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)

import time
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_classification

def create_dataset():
    X, y = make_classification( n_samples=1250,
                                n_features=2,
                                n_redundant=0,
                                n_informative=2,
                                random_state=5,
                                n_clusters_per_class=1)
    rng = np.random.RandomState(2)
    X += 3 * rng.uniform(size = X.shape)
    linearly_separable = (X, y)
    X = StandardScaler().fit_transform(X)
    return X, y


# (a)
# YOUR CODE HERE

def plotter(classifier, X, X_test, y_test, title, ax=None):
    # plot decision boundary for given classifier
    plot_step = 0.02
    x_min, x_max = X[:, 0].min() - 1, X[:,0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:,1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, plot_step), 
                            np.arange(y_min, y_max, plot_step)) 
    Z = classifier.predict(np.c_[xx.ravel(),yy.ravel()])
    Z = Z.reshape(xx.shape)
    if ax:
        ax.contourf(xx, yy, Z, cmap = plt.cm.Paired)
        ax.scatter(X_test[:, 0], X_test[:, 1], c = y_test)
        ax.set_title(title)
    else:
        plt.contourf(xx, yy, Z, cmap = plt.cm.Paired)
        plt.scatter(X_test[:, 0], X_test[:, 1], c = y_test)
        plt.title(title)


X,y = create_dataset()

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

Tree_clf = DecisionTreeClassifier(random_state=0)
RF_clf = RandomForestClassifier(random_state=0)
ADA_clf = AdaBoostClassifier(random_state=0)
LR_clf = LogisticRegression(random_state=0)
MLP_clf = MLPClassifier(random_state=0)
SVM_clf = SVC()

classifiers = [Tree_clf,RF_clf,ADA_clf,LR_clf,MLP_clf,SVM_clf]
titles = ['DecisionTreeClassifier','RandomForestClassifier','AdaBoostClassifier','LogisticRegression','MLPClassifier','SVC']
for idx,clf in enumerate(classifiers):
    clf.fit(X_train, y_train)
    plotter(clf, X, X_test, y_test, titles[idx], ax=None)
    plt.show()

# (b)
# YOUR CODE HERE
classifiers = [Tree_clf,RF_clf,ADA_clf,LR_clf,MLP_clf,SVM_clf]
titles = ['DecisionTreeClassifier','RandomForestClassifier','AdaBoostClassifier','LogisticRegression','MLPClassifier','SVC']
acc_avg = []
for idx,clf in enumerate(classifiers):
    acc = []
    for k in range(10):
        indx = np.array(range(0,len(X_train)))
        np.random.shuffle(indx)
        acc_i = [[] for i in range(11)]
        for idx,i in enumerate([50]+list(np.arange(100,1100,100))):
            clf.fit(X_train[indx[:i],:], y_train[indx[:i]])
            y_pred = clf.predict(X_test)
            acc_i[idx] = sum(y_pred==y_test)/len(y_pred)
        acc.append(acc_i)
    acc  = np.array(acc)
    acc_avg.append(np.mean(acc,axis=0))
acc_avg = np.array(acc_avg)

## plot 
x = np.arange(11)
total_width, n = 0.8, 6
width = total_width / n
x = x - (total_width - width) / 2
for i in range(n):
    plt.bar(x+i*width, acc_avg[i,:],  width=width, label=titles[i])
plt.legend()
plt.show()


# (c)
# YOUR CODE HERE

classifiers = [Tree_clf,RF_clf,ADA_clf,LR_clf,MLP_clf,SVM_clf]
titles = ['DecisionTreeClassifier','RandomForestClassifier','AdaBoostClassifier','LogisticRegression','MLPClassifier','SVC']
ttime_avg = []
for idx,clf in enumerate(classifiers):
    ttime = []
    for k in range(10):
        indx = np.array(range(0,len(X_train)))
        np.random.shuffle(indx)
        ttime_i = [[] for i in range(11)]
        for idx,i in enumerate([50]+list(np.arange(100,1100,100))):
            start = time.time()
            clf.fit(X_train[indx[:i],:], y_train[indx[:i]])
            end = time.time()
            ttime_i[idx] = end-start
        ttime.append(ttime_i)
    ttime  = np.array(ttime)
    ttime_avg.append(np.mean(ttime,axis=0))
ttime_avg = np.array(ttime_avg)

## plot
x = np.arange(11)
total_width, n = 0.8, 6
width = total_width / n
x = x - (total_width - width) / 2
for i in range(n):
    plt.bar(x+i*width, ttime_avg[i,:],  width=width, label=titles[i])
plt.legend()
plt.show()