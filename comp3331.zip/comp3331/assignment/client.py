from socket import *
import pickle
import time
import threading
import sys
from packet import Packet
##t1.setDaemon(True)##
serverName = 'localhost'
serverPort = int(sys.argv[1])
valid = False
messageSize = 2048
Gap = 0.2


def receiveFunction():
    global TCP_Socket
    global valid
    while True:
        receivedMessage = TCP_Socket.recv(messageSize)
        receivedMessage = receivedMessage.decode()
        print(receivedMessage)
        if ('Welcome' in receivedMessage):
            valid = True
        if ('timeout' in receivedMessage):
            return

# establish connection
TCP_Socket2 = socket(AF_INET, SOCK_STREAM)
TCP_Socket2.connect((serverName, serverPort))
receivedMessage = TCP_Socket2.recv(messageSize)
receivedMessage = receivedMessage.decode()
currPort = int(receivedMessage)
print(currPort)
TCP_Socket2.close()
time.sleep(Gap)                                 #wait for sever start
TCP_Socket = socket(AF_INET, SOCK_STREAM)
TCP_Socket.connect((serverName, currPort))
t1 = threading.Thread(target=receiveFunction)
t1.start()
while True:
    time.sleep(Gap)                             #wait for check valid change
    if (not valid):
        # get valid information
        validInfo = []
        validInfo.append(input("Username: "))
        validInfo.append(input("Password: "))
        TCP_Socket.send(pickle.dumps(validInfo))
    else:
        message = input()
        if message == "logout":
            valid = False
        #print(mes)
        TCP_Socket.send(message.encode())
