import socket
import sys

serverPort = sys.argv[1]
Sockets = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
Sockets.bind(('', int(serverPort)))
Sockets.listen(1)

while True:
    connectionSocket, connectionAddress = Sockets.accept()
    try:
        information = connectionSocket.recv(2048)
        information = information.decode()
        print(information)
        fName = information.split()[1]
        fName = fName.replace('/','')
        
        request = open(fName, 'rb')
        data = request.read()
        if("html" in fName):
            head = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n"
        elif("png" in fName):
            head = "HTTP/1.1 200 OK\r\nContent-Type: image/png\r\n\r\n"
        elif("jpg" in fName):
            head = "HTTP/1.1 200 OK\r\nContent-Type: image/jpg\r\n\r\n"
        head = head.encode()
        #print("1111111111111111111111111111111")
        connectionSocket.sendall(head)
        connectionSocket.sendall(data)
        connectionSocket.close()
    except Exception:
        head = "HTTP/1.1 404 File not found\r\n\r\n"
        head = head.encode()
        data = "<h1><center>File does not exist</center></h1>"
        connectionSocket.sendall(head)
        connectionSocket.sendall(data)
        connectionSocket.close()
