import pandas as pd
import sys
import numpy as np
from sklearn.naive_bayes import MultinomialNB

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report

from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk.corpus import stopwords
en_stops = set(stopwords.words('english'))

train = pd.read_csv(sys.argv[1], sep='\n', header=None)
tests = pd.read_csv(sys.argv[2], sep='\n', header=None)
trains = []
labels = []

test = []

numbers = []

delete_uml = []
delete_stopwords = []
delete_o = []
stop = 0

for string in train.to_numpy():
    s = string[0].replace('\t',' ')
    t = s.split(' ')
    if(t[-2] == 'neutral'):
        continue
    labels.append(t[-3])
    for i in t:
        if i in en_stops:
            delete_stopwords.append(i)
        if i.startswith('https://') or i.startswith('http://'):
            delete_uml.append(i)
    for i in delete_stopwords:
        if i in t:
            t.remove(i)
    for i in delete_uml:
        if i in t:
            t.remove(i)
    numbers.append(t[0])    
    t.pop(0)
    t.pop()
    t.pop()
    t.pop()
    s = ' '.join(t)
    s = s.replace('!','')
    s = s.replace('.', '')
    s = s.replace(',', '')
    s = s.replace('?', '')
    s = s.replace('-', '')
    s = s.replace('“', '')
    s = s.replace('”', '')
    s = s.replace('|', '')
    s = s.replace('/', ' ')
    s = s.replace('&', ' ')
    s = s.replace(':', ' ')
    s = s.replace("'", ' ')
    s = s.replace(';', ' ')
    s = s.replace('[', ' ')
    s = s.replace('{', ' ')
    s = s.replace(']', ' ')
    s = s.replace('}', ' ')
    s = s.replace('*', ' ')
    s = s.replace('~', ' ')
    s = s.replace('\\\\', ' ')
    s = s.replace('(', ' ')
    s = s.replace(')', ' ')
    s = s.replace('+', ' ')
    s = s.replace('=', ' ')
    s = s.replace('<', ' ')
    s = s.replace('>', ' ')
    t5 = s.split(' ')
    for i in t5:
        if len(i) == 1:
            delete_o.append(i)
    for i in delete_o:
        if i in t5:
            t5.remove(i)
    s = ' '.join(t5)
    #if 'positive' in string[0]:
    #    labels.append('positive')
    #if 'negative' in string[0]:
    #    labels.append('negative')
    #if 'neutral' in string[0]:
    #    labels.append('neutral')

    trains.append(s)
#print(trains[2])
#print(labels)
labels_t = []
delete_uml_t = []
delete_stopwords_t = []
delete_o_t = []

for string in tests.to_numpy():
    s1 = string[0].replace('\t',' ')
    t1 = s1.split(' ')
    #print(t1[-2])
    if(t1[-2] == 'neutral'):
        continue
    labels_t.append(t1[-3])
    for i in t1:
        if i in en_stops:
            delete_stopwords_t.append(i)
        if i.startswith('https://') or i.startswith('http://'):
            delete_uml_t.append(i)
    for i in delete_stopwords_t:
        if i in t1:
            t1.remove(i)   
    for i in delete_uml_t:
        if i in t1:
            t1.remove(i)
    t1.pop(0)
    t1.pop()
    t1.pop()
    t1.pop()
    s1 = ' '.join(t1)
    s1 = s1.replace('!','')
    s1 = s1.replace('.', '')
    s1 = s1.replace(',', '')
    s1 = s1.replace('?', '')
    s1 = s1.replace('-', '')
    s1 = s1.replace('“', '')
    s1 = s1.replace('”', '')
    s1 = s1.replace('|', '')
    s1 = s1.replace('/', ' ')
    s1 = s1.replace('&', ' ')
    s1 = s1.replace(':', ' ')
    s1 = s1.replace("'", ' ')
    s1 = s1.replace(';', ' ')
    s1 = s1.replace('[', ' ')
    s1 = s1.replace('{', ' ')
    s1 = s1.replace(']', ' ')
    s1 = s1.replace('}', ' ')
    s1 = s1.replace('*', ' ')
    s1 = s1.replace('~', ' ')
    s1 = s1.replace('\\\\', ' ')
    s1 = s1.replace('(', ' ')
    s1 = s1.replace(')', ' ')
    s1 = s1.replace('+', ' ')
    s1 = s1.replace('=', ' ')
    s1 = s1.replace('<', ' ')
    s1 = s1.replace('>', ' ')
    t6 = s1.split(' ')
    for i in t6:
        if len(i) == 1:
            delete_o_t.append(i)
    for i in delete_o_t:
        if i in t6:
            t6.remove(i)
    s1 = ' '.join(t6)
    #if 'positive' in string[0]:
    #    labels.append('positive')
    #if 'negative' in string[0]:
    #    labels.append('negative')
    #if 'neutral' in string[0]:
    #    labels.append('neutral')

    test.append(s1)
#print(trains[2])
#print(labels)

cv = CountVectorizer()
cv_fit=cv.fit_transform(trains) 
#print(train.to_numpy())

#print(cv.get_feature_names())
#print(len(labels))

X = cv_fit.toarray()
Y = labels
Y_t = labels_t
clf = MultinomialNB()
clf = clf.fit(X, Y)

test_p = cv.transform(test).toarray()
X_t = cv.transform(test).toarray()

list_t = clf.predict(test_p)

j = 0
for i in numbers:
    if j>=len(list_t) :
        break;
    print(i + ' ' + list_t[j])
    j = j + 1
'''
#print(clf.predict(test_p))
#print(clf.predict(test2))
predicted_y = clf.predict(X_t)
print(Y_t, predicted_y)
print(clf.predict_proba(X_t))
print(accuracy_score(Y_t, predicted_y))
print(precision_score(Y_t, predicted_y, average='macro'))
#print(recall_score(Y_t, predicted_y), average=None)
print(f1_score(Y_t, predicted_y, average='micro'))
print(f1_score(Y_t, predicted_y, average='macro'))
print(classification_report(Y_t, predicted_y))
#print(clf.predict([[2., 2.]]))
#target_names = []
#print(classification_report(y_true, y_pred, target_names=target_names))
'''
