--Comp3311 Assignment1

--1.List all persons who are both clients and staff members. Order the result by pid in ascending order.

create or replace view Q1(pid, firstname, lastname) as
select p.pid, p.firstname, p.lastname
from person p, client c, staff s
where p.pid = c.pid and p.pid = s.pid
group by p.pid
order by p.pid asc
;

--2.For each car brand, list the car insured by the most expensive policy (the premium, i.e., the sum of its coverages' rates). Order the result by brand, and then by car id, pno if there are ties, all in ascending order. 

create or replace view Allcars(brand, car_id, pno, premium) as
select i.brand, i.id, p.pno, r.rate
from insured_item i, policy p, rating_record r, coverage c
where i.id = p.id and p.pno = c.pno and c.coid = r.coid
;

create or replace view Expensive(brand, price) as 
select brand, max(premium)
from Allcars
group by brand
;

create or replace view Q2(brand, car_id, pno, premium) as
select a.brand, car_id, pno, max(premium)
from Allcars a, Expensive e
where a.brand = e.brand and a.premium = e.price
group by a.brand, car_id, pno
order by a.brand asc, car_id asc, pno asc
;

--3.List all the staff members who did not sell any policies in the last 365 calendar days (from today). Note that policy.sid records the staff who sold this policy, underwritten_by.wdate records the date a policy is sold (we ignore the status here). Order the result by pid in ascending order. 

create or replace view HavePolicy(pid, firstname, lastname) as
select s.pid, p.firstname, p.lastname
from staff s, person p, underwritten_by u, policy po
where s.pid = p.pid and s.sid = po.sid and s.sid = u.sid and u.wdate >= CURRENT_DATE - INTERVAL '1 YEAR' and u.wdate <= CURRENT_DATE
group by s.pid, p.firstname, p.lastname
;

create or replace view Q3(pid, firstname, lastname) as
select s.pid, p.firstname, p.lastname
from staff s, person p, underwritten_by u, policy po, HavePolicy h
where s.pid <> h.pid and s.pid = p.pid
group by s.pid, p.firstname, p.lastname
order by s.pid
;

--4.For each suburb in NSW, compute the number of policies that have been sold to the policy holders living in the suburb (regardless of the policy status). Order the result by Number of Policies (npolicies), then by suburb, in ascending order. Exclude suburbs with no sold policies. Furthermore, suburb names are output in all uppercase. 

create or replace view NSW_suburbs(suburb, policy) as
select p.suburb, po.pno
from person p, client c, policy po, insured_by i
where p.state = 'NSW' and p.pid = c.pid and i.cid = c.cid and po.pno = i.pno
;

create or replace view Q4(suburb, npolicies) as
select UPPER(N.suburb), count(*)
from NSW_suburbs N
group by N.suburb
order by count(*) asc, N.suburb asc
;

--5.Find the policies which are rated, underwritten, and sold by the same staff member. Order the result by pno in ascending order. 

create or replace view Q5(pno, pname, pid, firstname, lastname) as
select po.pno, po.pname, p.pid, p.firstname, p.lastname
from person p, policy po, staff s, rated_by r, underwritten_by u, underwriting_record ur, coverage c, rating_record rr
where p.pid = s.pid and s.sid = r.sid and s.sid = u.sid and po.sid = u.sid and u.urid = ur.urid and ur.pno = po.pno and rr.rid = r.rid and rr.coid = c.coid and c.pno = po.pno
order by po.pno asc
;
--6.List the staff members (their firstname, a space and then the lastname as one column called name) who only sell policies to cover one brand of cars. Order the result by pid in ascending order. 

create or replace view per_brands(pid, name, pno, brand) as
select p.pid, p.lastname, po.pno, i.brand
from person p, staff s, policy po, insured_item i
where p.pid = s.pid and s.sid = po.sid and po.id = i.id
group by p.pid, p.lastname, po.pno, i.brand
;

create or replace view howmany_brand(pid, name, brands) as
select p.pid, p.lastname, count(*)
from person p, per_brands pe
where p.lastname = pe.name and p.pid = pe.pid
group by p.pid, p.lastname, pe.brand
;

create or replace view how_brand(pid, name, brands) as
select p.pid, p.lastname, count(*)
from person p, howmany_brand h
where p.lastname = h.name and p.pid = h.pid
group by p.pid, p.lastname
;

create or replace view Q6(pid, name, brand) as
select p.pid, CONCAT(p.firstname, ' ', p.lastname), i.brand
from person p, staff s, policy po, insured_item i, how_brand h
where p.pid = s.pid and s.sid = po.sid and po.id = i.id and h.brands <= 1 and h.pid = p.pid
;

--7.List clients (their firstname, a space and then the lastname as one column called name) who hold policies to cover all brands of cars recorded in the database. Order the result by pid in ascending order. 

create or replace view clients_po_brand(pid, name, brand) as
select p.pid, CONCAT(p.firstname, ' ', p.lastname), i.brand
from person p, client c, policy po, insured_item i, insured_by ib
where p.pid = c.pid and c.cid = ib.cid and ib.pno = po.pno and po.id = i.id
group by p.pid, i.brand
;

create or replace view howmany_client(pid, name, brands) as
select p.pid, CONCAT(p.firstname, ' ', p.lastname), count(*)
from person p, clients_po_brand cl
where p.pid = cl.pid
group by p.pid
;

create or replace view howmany_brands(brand) as
select distinct ii.brand
from insured_item ii
group by ii.brand
;

create or replace view Q7(pid, name) as
select p.pid, CONCAT(p.firstname, ' ', p.lastname)
from person p, howmany_client hc
where  p.pid = hc.pid and hc.brands >= (select count(*) from howmany_brands)
;

--8.For each policy X, compute the number of other policies (excluding X) whose coverage is contained by the coverage of X. For example, if a policy X has 3 coverages (identified by cname), say {C1, C2, C3}, and another policy Y has 2 coverages, {C1, C3}, we say Y's coverage is contained by X's. In case if X's and Y's coverages are identical, their coverages are contained by each other. Order the result by pno in ascending order. Exclude policies that contain no other policies in your output (i.e., exclude those with npolicies being 0). 

create or replace view policy_coverage(coid, pno, cname) as
select c.coid, po.pno, c.cname
from policy po, coverage c
where po.pno = c.pno
order by po.pno
;

create or replace view counts(pno, counta) as
select pno,count(*)
from policy_coverage
group by pno
order by pno
;

create or replace view policy_copy(coid, pno, cname) as
select *
from policy_coverage
order by pno
;

create or replace view conP(pno, cname) AS
select pno, array_to_string(array_agg(cname), ',')
from policy_coverage
group by pno
order by pno
;

create or replace view result(pno, npolicies) as
select *
from conP
order by pno
;

create table result_table as select * from result;

create or replace function 
      CountP()
      returns TABLE (
      countnum INT
)
as $$
declare
    i record;
    j record;
    lasti integer := 0;    
    lastone integer := 0; 
    belong integer := 0;
    count_p integer := 0;
    lastpno integer := 100;
    switch integer := 0;
begin
--raise notice '%',count_p;
    select count(*) into switch from policy_coverage where pno = (select max(pno) from policy);
    for i in select pno, cname from conP loop
        lasti := lasti + 1;
        for j in select pno, cname from policy_coverage loop
            lastone := lastone + 1;
            if i.pno <> j.pno then
                if lastpno <> j.pno and lastpno <> 100 and belong = 0 then 
                    count_p := count_p + 1;
                end if;
                
                if lastpno <> j.pno and lastpno <> 100 and belong = 1 then
                    belong := 0;
                end if;
                
                if position(j.cname in i.cname) > 0 then 
                    --switch := switch + 1;
                else
                    --switch := switch + 1;
                    belong := 1;
                end if;
                
                if lastone = (select count(*) from policy_coverage) then
                    if belong = 0 then
                        count_p := count_p + 1;
                    else
                        belong := 0;
                    end if;
                end if;
                
                if lasti = (select count(*) from conP) and lastone = (select count(*) from policy_coverage) - switch then
                    if belong = 0 then
                        count_p := count_p + 1;
                    else
                        belong := 0;
                    end if;
                end if;
                
                lastpno := j.pno;
            end if;
            --raise notice '%',count_p;
         end loop;
         countnum := count_p;
         --switch := lastone;
         lastone := 0;
         lastpno := 100;
         --belong := 0;
         
         update result_table
         set npolicies = count_p
         where pno = i.pno;
         
         --switch := switch + count_p;
         count_p := 0;
         return next;
     end loop;
     --return switch;
end;
$$ language plpgsql;               

select CountP();

create or replace view Q8(pno, npolicies) as
select *
from result_table
;


create or replace function ratechange(Adj integer) returns integer
as $$
declare 
    res integer;
    countb integer;
    i record;
    j record;
begin
    countb = 0;
    for i in select effectivedate, expirydate, status, pno from policy loop
        if (i.effectivedate < CURRENT_DATE and CURRENT_DATE < i.expirydate and i.status = 'E') then
            countb := countb + 1;
            for j in select pno, coid from coverage loop
                update rating_record
                set rate = rate + rate * Adj * 0.01
                where i.pno = j.pno and coid = j.coid;
            end loop;
        end if;
    --if position('abc abd' in 'abd ad ac abc') > 0 then
    --    countb := 100;
    --end if;
    end loop;
    return countb;
end;
$$ language plpgsql;


create or replace view staff_p(pid,pno,pname) as
select c.pid, p.pno, p.pname
from client c, policy p, insured_by i, staff s
where c.cid = i.cid and i.pno = p.pno and c.pid = s.pid
group by p.pno, c.pid;

create or replace view client_p(cid,pno) as
select c.cid, p.pno
from client c, policy p, insured_by i
where c.cid = i.cid and i.pno = p.pno
group by c.cid, p.pno;

create function approved() returns trigger
as $$
declare key int;
begin
    if(new.status = 'E' and new.pname not in (select pname from staff_p where new.pno = pno)) then
        select c.cid into key
        from client c, insured_by i
        where c.cid = i.cid and i.pno = new.pno;
        update policy
        set expirydate = expirydate + interval '30 days'
        where pno in (select pno from client_p where cid = key and pno != new.pno);
    end  if;
    return new;
end;
$$ language plpgsql;


create trigger approved
after update on policy
for each row when (new.status = 'E') execute procedure approved();



